package Frames;
import javax.swing.*;
import java.awt.*;


public class Frame2 {
	public static void main(String[] args) {
		LoginFrame frame2 = new LoginFrame();
		
		
		JLabel LoginText = new JLabel();
		LoginText.setText("Login");
		LoginText.setVisible(true);
		LoginText.setBounds(120,60,230,60);
		LoginText.setFont(new Font("Roboto", Font.ITALIC, 50));
		frame2.add(LoginText);
		
		// email
		JLabel emailText = new JLabel();
		emailText.setText("Email");
		emailText.setVisible(true);
		emailText.setBounds(70,170,230,30);
		frame2.add(emailText);
		
		JTextField emailTextField = new JTextField();
		emailTextField.setVisible(true);
		emailTextField.setBounds(70,200,230,30);
		frame2.add(emailTextField);
		
		//password
		JLabel passwordText = new JLabel();
		passwordText.setText("Password");
		passwordText.setVisible(true);
		passwordText.setBounds(70,230,230,30);
		frame2.add(passwordText);
		
		JTextField passwordTextField = new JTextField();
		passwordTextField.setVisible(true);
		passwordTextField.setBounds(70,260,230,30);
		frame2.add(passwordTextField);
		
		//next Button
		JButton nextBtn = new JButton();
		nextBtn.setVisible(true);
		nextBtn.setBounds(110,330,140,30);
		nextBtn.setText("Next");
		frame2.add(nextBtn);
		
		
		
		
		
		
		
	}
	
}
