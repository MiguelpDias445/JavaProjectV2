package Frames;
import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame{
	LoginFrame(){
		this.setVisible(true);
		this.setSize(400,500);
		this.setBackground(new Color(255,255,255));
		this.setResizable(false);
		this.setLayout(null);
		this.setTitle("Login Frame");
	}
	
}
