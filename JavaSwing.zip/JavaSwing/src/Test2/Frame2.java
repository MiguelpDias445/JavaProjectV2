package Test2;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Frame2 {

	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setSize(400,500);
		frame.setLayout(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setBackground(new Color(255,255,255));
		frame.setResizable(false);
		frame.setTitle("CAmoda Shoping");
		frame.setVisible(true);
		
		JLabel label = new JLabel("Email: ");
		label.setBounds(20, 200, 200, 30);
		frame.add(label);
		
		
		
		
		
		
		JTextField email = new JTextField();
		email.setBounds(80, 200, 200, 30);
		frame.add(email);

		frame.setVisible(true);
		frame.repaint();
		frame.revalidate();
		
		JLabel label3 = new JLabel("Login");
		label3.setBounds(100, 50, 200, 100);
		frame.add(label3);
		label3.setFont(new Font("Montserrat",Font.PLAIN, 50));
		
		JLabel label1 = new JLabel("Password: ");
		label1.setBounds(20, 250, 200, 30);
		frame.add(label1);
		
		JTextField name = new JTextField();
		name.setBounds(80, 250, 200, 30);
		frame.add(name);

		JButton botao = new JButton("Next");
		botao.setBounds(80, 300, 200, 30);
		frame.add(botao);
		frame.setVisible(true);
		
		
		
	}

}
