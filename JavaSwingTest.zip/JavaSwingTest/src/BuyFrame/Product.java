package BuyFrame;
import javax.swing.*;
import java.awt.*;

public class Product extends JPanel{
	private boolean sale;
	private double discount;
	private double price;
	private String description;
	private String title;
	
	JLabel titleText = new JLabel(getTitle());
	JLabel priceText = new JLabel();
	JButton btn = new JButton();
	
	
	ImageIcon icon;  
    Image image1;
    Image newImage1;
    ImageIcon newIcon;
		
	public void setImage(String src) {
		icon = new ImageIcon(src);
		image1 = icon.getImage();
		newImage1 = image1.getScaledInstance(90, 110, Image.SCALE_SMOOTH);
		newIcon = new ImageIcon(newImage1);
		btn.setIcon(newIcon);
	}
	
	public Product(){
		this.setBackground(new Color(241,220,219));
		this.setSize(100,150);
		this.sale = true;
		priceText.setVisible(true);
		titleText.setVisible(true);
		priceText.setFont(new Font("Sans-Serif",Font.BOLD, 15));
		
		titleText.setBounds(0, 0, 100, 20);
		priceText.setBounds(25, 90, 90, 100);
		btn.setBounds(5,20,90,110);
		this.setLayout(null);
		
		
		this.add(btn);
		this.add(priceText);
		this.add(titleText);
		
	}
	
	//getters & setters
	public Product(double discount){
		
	}
	public void setPrice(double price) {
		this.price = price;
		priceText.setText(String.format("%.2f", price));
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public void setSale(boolean sale) {
		this.sale = sale;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	
	public boolean getSale() {
		return sale;
	}
	
	public double getDiscount() {
		return discount;
	}
	
	public double getPrice() {
		return price;
	}
	public String getTitle() {
		return title;
	}
	public String getDescription() {
		return description;
	}
	
}
