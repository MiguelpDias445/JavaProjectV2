package BuyFrame;

import java.awt.*;
import javax.swing.ImageIcon;
import Testing.MainFrame;
import javax.swing.*;

public class ScreenTest {

	public static void main(String[] args) {
		MainFrame frame = new MainFrame();
		
		Product purse = new Product();
		purse.setImage("ProductsImages/Purse1.jpg");
		purse.setPrice(560.99);
		purse.titleText.setText("Gorgeous pink purse");
		purse.setVisible(true);
		purse.setBounds(10,60,100,150);
		//purse.btn.action(null, purse)
		
		Product purse2 = new Product();
		purse2.setPrice(490.99);
		purse2.titleText.setText("Test");
		purse2.setImage("pic.png.jpeg");		
		purse2.setVisible(true);
		purse2.setBounds(120,60,100,150);
		
		Product purse3 = new Product();
		purse3.setPrice(490.99);
		purse3.titleText.setText("Test2");
		purse3.setImage("pic.png.jpeg");		
		purse3.setVisible(true);
		purse3.setBounds(230,60,100,150);
		
		
		frame.add(purse);
		frame.add(purse2);
		frame.add(purse3);
		
		frame.setVisible(true);
		
		
	}

}
