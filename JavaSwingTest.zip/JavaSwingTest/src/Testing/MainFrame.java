package Testing;
import javax.swing.*;

public class MainFrame extends JFrame{
	public MainFrame(){
		this.setVisible(true);
		this.setLayout(null);
		this.setResizable(false);
		this.setSize(400,500);
		this.setTitle("CAmoda shoping");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel frame = new JPanel();
		JScrollPane productsPane = new JScrollPane(frame);
		
		
	}
}
