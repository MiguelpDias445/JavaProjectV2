/**
 * 
 */
/**
 * 
 */
module JavaSwingTest {
	requires java.desktop;
}